package it.polito.po.test;

import static org.junit.Assert.*;

import java.util.*;
import org.junit.Before;
import org.junit.Test;

import operations.*;

public class TestR1 {
	Operations op = new Operations();
	int j = 0;
	String result;
	String expected;

	@Before
	public void setUp() {
		op = new Operations();
	}

	@Test
	public void addProductTypes1() throws OException {
		j = op.addProductType("sofa", 4, 300);

		assertEquals(1200, j);
	}

	@Test(expected = OException.class)
	public void addProductTypes2() throws OException {
		j = op.addProductType("table", 3, 100);
		j = op.addProductType("table", 2, 80);
	}

	@Test
	public void getNumberOfProducts1() throws OException {
		j = op.addProductType("sofa", 4, 300);
		j = op.getNumberOfProducts("sofa");

		assertEquals(4, j);
	}

	@Test(expected = OException.class)
	public void getNumberOfProducts2() throws OException {
		j = op.getNumberOfProducts("table");
	}

	@Test
	public void groupingPTsByPrices() throws OException {
		op.addProductType("sofa", 4, 300);
		op.addProductType("table", 2, 250);
		op.addProductType("desk", 2, 250);
		SortedMap<Integer, List<String>> map1 = op.groupingProductTypesByPrices();

		assertNotNull("Missing map grouping product types by prices", map1);
		assertEquals("{250=[desk, table], 300=[sofa]}", map1.toString());
	}

	@Test
	public void addDiscount1() {
		j = op.addDiscount("customer1", 15);

		assertEquals( 15, j);
	}

	@Test
	public void addDiscount2() {
		j = op.addDiscount("customer1", 15);
		j = op.addDiscount("customer1", 15);

		assertEquals( 30, j);
	}

	@Test
	public void customerOrder1() throws OException {
		op.addProductType("sofa", 1, 300);
		op.addDiscount("customer1", 20);
		j = op.customerOrder("customer1", "sofa:1", 10);

		assertEquals( 290, j);
	}

	@Test // (expected=OException.class)
	public void customerOrder2() throws OException {
		op.addProductType("sofa", 1, 300);
		op.addDiscount("customer1", 20);
		j = op.customerOrder("customer1", "sofa:2", 10); // only one sofa available
		j = op.getNumberOfProducts("sofa");
		
		assertEquals( 1, j);
	}

	@Test(expected=OException.class)
	public void customerOrder3() throws OException {
		op.addProductType("sofa", 1, 300);
		op.addDiscount("customer1", 20);
		
		op.customerOrder("customer1", "sofa:1", 30);
	}

	@Test
	public void customerOrder4() throws OException {
		op.addProductType("sofa", 1, 300);
		op.addDiscount("customer1", 20);
		j = op.customerOrder("customer1", "sofa:1", 20);
		
		assertEquals( 280,j );

		j = op.getNumberOfProducts("sofa");

		assertEquals( 0, j);
	}

	@Test
	public void customerOrder5() throws OException {
		op.addProductType("sofa", 1, 300);
		op.addProductType("table", 2, 250);
		op.addDiscount("customer1", 20);
		op.addDiscount("customer1", 30);
		j = op.customerOrder("customer1", "sofa:1", 20);
		j = op.customerOrder("customer1", "table:1", 20);
		j = op.getDiscountAvailable("customer1");
		
		assertEquals(10, j);
	}

	@Test
	public void customerOrder6() throws OException {
		op.addProductType("sofa", 1, 300);
		op.addProductType("table", 2, 250);
		op.addDiscount("customer1", 20);
		op.addDiscount("customer1", 30);
		j = op.customerOrder("customer1", "sofa:1 table:1", 20);
		j = op.getDiscountAvailable("customer1");
		
		assertEquals(30, j);
	}
}
