package it.polito.po.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.*;
import org.junit.Before;
import org.junit.Test;

import operations.*;

public class TestR3 {
	Operations op = new Operations();
	int j = 0;
	String result;
	String expected;

	@Before
	public void setUp() throws OException {
		op = new Operations();
		op.addProductType("sofa", 4, 300);
		op.addProductType("table", 3, 100);
		op.addDiscount("customer1", 15);
		op.customerOrder("customer1", "sofa:1", 10);
	}

	@Test
	public void evalByCustomer1() throws OException {
		j = op.evalByCustomer("customer1", "sofa", 8);
		assertEquals(1, j);
	}

	@Test
	public void evalByCustomer2() throws OException {
		j = op.customerOrder("customer1", "table:2", 0);
		j = op.evalByCustomer("customer1", "sofa", 8);
		j = op.evalByCustomer("customer1", "table", 6);
		assertEquals(2, j);
	}

	@Test(expected = OException.class)
	public void evalByCustomer3() throws OException {
		j = op.evalByCustomer("customer1", "table", 8); // no purchase of table
	}

	@Test(expected = OException.class)
	public void evalByCustomer4() throws OException {
		j = op.evalByCustomer("customer1", "sofa", 8);
		j = op.evalByCustomer("customer1", "sofa", 6);
	}

	@Test(expected = OException.class)
	public void evalByCustomer5() throws OException {
		j = op.evalByCustomer("customer1", "sofa", 11);
	}

	@Test
	public void getScoreFromProductType1() throws OException {
		j = op.evalByCustomer("customer1", "sofa", 8);
		j = op.getScoreFromProductType("customer1", "sofa");
		assertEquals(8, j);
	}

	@Test(expected = OException.class)
	public void getScoreFromProductType2() throws OException {
		j = op.evalByCustomer("customer1", "sofa", 8);
		j = op.getScoreFromProductType("customer1", "table");
	}

	@Test
	public void groupingCustomersByScores1() throws OException {
		SortedMap<Integer, List<String>> map;
		op.addDiscount("customer2", 15);
		op.addDiscount("customer3", 15);

		j = op.customerOrder("customer3", "sofa:1", 10);
		j = op.customerOrder("customer2", "sofa:1", 5);
		j = op.evalByCustomer("customer3", "sofa", 7);
		j = op.evalByCustomer("customer2", "sofa", 9);

		map = op.groupingCustomersByScores("sofa");

		assertNotNull("Missing map with customers by scores", map);
		assertEquals("{7=[customer3], 9=[customer2]}", map.toString());
	}

	@Test
	public void groupingCustomersByScores2() throws OException {
		SortedMap<Integer, List<String>> map;
		j = op.addDiscount("customer3", 15);
		j = op.addDiscount("customer2", 10);
		j = op.addDiscount("customer1", 20);
		j = op.customerOrder("customer3", "table:1", 10);
		j = op.customerOrder("customer2", "table:1", 5);
		j = op.customerOrder("customer1", "table:1", 5);
		j = op.evalByCustomer("customer3", "table", 7);
		j = op.evalByCustomer("customer2", "table", 9);
		j = op.evalByCustomer("customer1", "table", 7);

		map = op.groupingCustomersByScores("table");

		assertNotNull("Missing map with customers by scores", map);
		assertEquals("{7=[customer1, customer3], 9=[customer2]}", map.toString());
	}

	@Test
	public void groupingCustomersByNumberOfProductsPurchased1() throws OException {
		SortedMap<Integer, List<String>> map;
		j = op.addDiscount("customer3", 15);
		j = op.addDiscount("customer2", 10);
		j = op.addDiscount("customer1", 20);
		j = op.customerOrder("customer3", "table:2", 10);
		j = op.customerOrder("customer2", "table:1", 5);
		j = op.customerOrder("customer1", "table:1", 5);

		map = op.groupingCustomersByNumberOfProductsPurchased();

		assertNotNull("Missing map with number of purchases", map);
		assertEquals("{1=[customer1, customer2], 2=[customer3]}", map.toString());
	}

	@Test
	public void largestExpenseForCustomer1() throws OException {
		SortedMap<String, Integer> map;
		j = op.addDiscount("customer3", 15);
		j = op.addDiscount("customer2", 10);
		j = op.addDiscount("customer1", 20);
		j = op.customerOrder("customer3", "table:2", 10);
		j = op.customerOrder("customer2", "table:1", 5);
		j = op.customerOrder("customer1", "table:1", 5);

		map = op.largestExpenseForCustomer();

		assertNotNull("Missing map with largest expenses", map);
		assertEquals("{customer1=290, customer2=95, customer3=190}", map.toString());
	}
}
