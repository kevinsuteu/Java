package operations;
import java.util.*;

class ProductType {
String name; int n; int price; 
ProductType (String name, int n, int price) {
	this.name = name; this.n = n; this.price = price;
}
String getPTName () {return name;}
Integer getPTPrice () {return price;}

SortedMap <Integer, List<String>> mapScoreCustomers = new TreeMap<>();


}
