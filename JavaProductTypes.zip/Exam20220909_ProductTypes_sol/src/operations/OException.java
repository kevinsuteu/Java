package operations;

@SuppressWarnings ("serial")
public class OException extends Exception {
	public OException (String reason) {
		super (reason);
	}
}
