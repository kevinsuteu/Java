package BankServices;

public class InvalidCode extends Exception {

}
