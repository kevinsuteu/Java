package BankServices;

public class InvalidValue extends Exception {

}
